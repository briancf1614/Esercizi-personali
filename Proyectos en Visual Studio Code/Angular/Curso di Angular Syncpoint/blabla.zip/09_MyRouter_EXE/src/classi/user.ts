export interface User {
    nome: string,
    password: string,
    email: string,
    hobby: string
}
