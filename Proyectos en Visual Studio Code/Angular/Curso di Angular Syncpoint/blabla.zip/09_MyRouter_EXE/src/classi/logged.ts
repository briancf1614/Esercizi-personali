export interface Logged {
    log: string,
    id: string,
    nome: string
}
