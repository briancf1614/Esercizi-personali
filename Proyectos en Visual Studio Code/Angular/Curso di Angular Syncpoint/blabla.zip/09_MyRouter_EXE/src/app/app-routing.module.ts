import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login/login.component';
import { NetworkComponent } from './network/network/network.component';
import { ProfileComponent } from './profile/profile/profile.component';






const routes: Routes = [
  { path: 'login', component: LoginComponent, title: 'Componente Uno' },
  { path: 'network', component: NetworkComponent, title: 'Componente Uno' },
  { path: 'profile', component: ProfileComponent, title: 'Componente Uno' },

  { path: '', redirectTo: 'uno', pathMatch: 'full' },

];

@NgModule({
  imports: [RouterModule.forRoot(routes,{
    bindToComponentInputs:true
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
