import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NetworkService {
  constructor(private httpClient:HttpClient) { }

  httpGetNetwork(url:string){
    return this.httpClient.get<any>(url)
    
  }
}
